# Bookstoast Rebrand — Shared Brief (read fully before starting)

Repo: `/home/raghav/src/bookstoast-platform` (a Ghost fork being relaunched as "Bookstoast").
ALL WORK HAPPENS IN THAT REPO — use absolute paths / set workdir for every command.

## STATE / CONCURRENCY (important)
- The working tree contains UNCOMMITTED changes from concurrent rebrand workstreams. NEVER run `git checkout`, `git reset`, `git stash`, `git add`, `git commit`, `git clean`, or any state-changing git command. NEVER revert or "fix up" changes outside your scope. Do not reformat unrelated code.
- Several agents edit this repo in parallel. You edit ONLY the files in YOUR scope (given in your task). If you notice issues elsewhere, include them in your report — do not fix them.
- Do NOT edit: node_modules, dist, build outputs, `.nxcache`, lockfiles, package.json identity fields (`@tryghost/*` names, versions), migrations, DB schema names, API paths (`/ghost/api/...`), or any binary/image files. If an image looks Ghost-branded, REPORT it, don't edit it.

## GOAL
A normal person using this product should never need to encounter "Ghost" as the product brand on any important user-facing surface. Keep internal machinery intact.

## THE RULES
1. USER-VISIBLE strings that name the product → "Bookstoast".
   - "Ghost" → "Bookstoast"; "Ghost(Pro)" / "Ghost Pro" → "Bookstoast Pro"; "Ghost.org" → "Bookstoast"; "Ghost Explore" → "Bookstoast Explore".
   - Covers: page copy, labels, buttons, menus, tooltips, placeholders, aria-labels, alt text, headings, error/toast text, dialog copy, email subjects.
   - Does NOT cover: code identifiers, class names, variable names, comments, JSDoc, internal log messages, CSS, test data names that aren't assertions. Do not rename those (out of scope; skip).
2. USER-VISIBLE links to Ghost-owned destinations → bookstoast.com equivalents:
   - `https://ghost.org/X` → `https://bookstoast.com/X`
   - `https://www.ghost.org/X` → `https://bookstoast.com/X`
   - `https://docs.ghost.org/X` → `https://bookstoast.com/docs/X`
   - `https://forum.ghost.org` → `https://bookstoast.com/forum`
   - `https://explore.ghost.org/X` → `https://bookstoast.com/explore/X`
   - Keep any query strings (e.g. `?utm_source=admin&utm_campaign=help`) but update any `ref=ghost.org` → `ref=bookstoast.com`.
3. KEEP exactly as-is (do not report unless clearly wrong):
   - Any `@tryghost/*` package/import references, `/ghost/` admin route paths, `ghost-admin-api` cookie/session names, `gh-*` CSS classes, internal identifiers.
   - `https://static.ghost.org/...` image/asset URLs (cannot be rehosted — leave, and REPORT a list of any you encounter in user-visible areas).
   - Functional service endpoints: `stripe.ghost.org`, `updates.ghost.org`, `*.ghost.org` API endpoints, `migrate.ghost.org`.
   - Legal attribution in About modals: the sentences "Copyright © 2013–YYYY Ghost Foundation, released under the MIT license." and "Ghost is a registered trademark of Ghost Foundation Ltd." (and their links) — KEEP the legal text; do not rebrand it. (The surrounding UI should already be Bookstoast.)
   - Test fixture data that is not user-facing (like test names, mock data) — leave.
4. TESTS: If a test in YOUR scope asserts an old string/URL that you changed, update the test so it passes. Do not run full test suites/builds (heavy); you may run a single targeted test file if it's quick. Report what you ran.
5. When unsure: prefer minimal change; if still unsure, SKIP and list it in your report. Never invent new pages/URLs beyond the mapping above.
6. Keep diffs tight: only change the smallest piece of text/URL; don't restructure code, don't reorder imports, don't "while I'm here" anything.

## REPORT FORMAT (final message back)
- Summary: what you changed (by category), count of files changed.
- List of files changed (paths).
- Anything skipped with reason; anything you noticed needing attention (esp. static.ghost.org images or binary assets).
- Commands run + results (if any).

---
# SCOPE DETAIL (find your section in your task; ONLY do yours)

## Scope A: React Admin (`apps/admin/**`, `apps/admin-x-framework/**`)
Sweep all user-visible "Ghost" strings + ghost.org links per The Rules. Known items include (re-grep to catch all; this is not exhaustive):
- `src/layout/app-sidebar/nav-ghost-pro.tsx`: menu label "Ghost(Pro)" → "Bookstoast Pro".
- `src/layout/app-sidebar/user-menu.tsx`: "Resources & guides" and help links → mapped links.
- `src/layout/app-sidebar/nav-settings.tsx`: help link → mapped.
- `src/settings/general/about.tsx`: help/docs/contributing links → mapped; keep legal paragraph (Rule 3).
- `src/settings/growth/explore.tsx` + `explore/testimonials-modal.tsx` + `explore.acceptance.test.tsx`: "Ghost Explore" → "Bookstoast Explore" etc; links → mapped; testimonial quotes referencing Ghost → Bookstoast; update its test.
- `src/settings/growth/recommendations/*`: strings + links (ghost.org/explore → bookstoast.com/explore).
- `src/settings/growth/network.tsx`: help link → mapped.
- `src/settings/membership/stripe/stripe-connect-modal.tsx`: copy (e.g. "Ghost collects no fees", "your Ghost site", "Ghost Resources") + links → mapped. (Image imports stay.)
- `src/settings/membership/analytics.tsx` + acceptance test: "Web analytics in Ghost is powered by..." + links → mapped.
- `src/settings/membership/gift-subscriptions.tsx`, `tiers/tier-detail-modal.tsx`, `offers.tsx`, `tips-and-donations.tsx`: help links → mapped.
- `src/settings/advanced/integrations/*`: transistor-modal, zapier-modal, pintura-modal, firstpromoter-modal, content-api-modal, custom-integration-modal, webhooks-table(+test): copy + links → mapped; `pqina.nl/pintura/ghost/?ref=ghost.org` → keep path, set `ref=bookstoast.com`.
- `src/settings/advanced/labs/beta-features.tsx`, `migration-tools/*`, `danger-zone.tsx`: copy + links → mapped.
- `src/settings/email-design/*` + `email/newsletters/newsletter-preview-content.tsx`: strings ("every email you send with Ghost...") + links → mapped.
- `src/settings/general/publication-language.tsx`, `invite-user-modal.tsx`, `users/role-selector.tsx`: copy + links → mapped.
- `src/settings/site/theme-modal.tsx` + `theme/official-themes.tsx`: "Ghost theme marketplace"/"Ghost Marketplace" → "Bookstoast ..." + links → mapped. DO NOT touch `src/settings/data/official-themes.ts` (install refs).
- `src/settings/utils/link-to-github-releases.ts` + `.test.ts`: change repo base `https://github.com/TryGhost/Ghost` → `https://github.com/Raghav1F7/bookstoast-platform` (keep the rest of the logic), update test expectations.
- `src/whats-new/hooks/use-changelog.ts` (+ test): `https://ghost.org/changelog.json` → `https://bookstoast.com/changelog.json`; default `https://ghost.org/changelog` → `https://bookstoast.com/changelog`; update test.
- `src/analytics/**` + `src/posts/analytics/**`: `google.com/s2/favicons?domain=ghost.org` → `domain=bookstoast.com`; `latest-post.tsx` fallback 'Ghost Site' → 'Bookstoast Site'.
- `src/shared/analytics/constants.ts`: `'ghost.org': 'Ghost'` → `'bookstoast.com': 'Bookstoast'` (keep other entries).
- `src/automations/components/automations-help-cards.tsx` + `utils/default-welcome-email-values.ts` (comment only, skip comment): FORUM/HELP links → mapped; titles "Automations in Ghost" → "in Bookstoast".
- `src/members/**`: members-help-cards, import-members links, multiple-active-subscriptions-banner, member-newsletters-field, member-delete-modal ("from Ghost"), delete-modal ("All Ghost data"), member-activity-feed comments (skip): copy + links → mapped. The CSV link `static.ghost.org/.../member-import-template.csv` — LEAVE, report it.
- `src/onboarding/components/onboarding-checklist.tsx` + any other onboarding strings: links → mapped.
- `src/layout/editor-sidebar.acceptance.test.tsx` / other tests: update assertions tied to changed strings ONLY.
- Re-grep before finishing: `cd /home/raghav/src/bookstoast-platform && git grep -n "Ghost\|ghost\.org" -- apps/admin/src apps/admin-x-framework/src` and report remaining intentional items.

## Scope B: Ember Admin (`apps/ember-admin/**`)
- `app/templates/application.hbs`: update banner copy "A new major version of Ghost is available!" → "Bookstoast"; "Update to Ghost 6.0" → "Update to Bookstoast 6.0"; "Your Ghost install is ready for a major update!" → "Bookstoast install".
- `app/services/upgrade-status.js`: messages Ghost → Bookstoast ("Sorry, Ghost is currently undergoing maintenance..." → "Bookstoast..."; "Ghost has been upgraded..." → "Bookstoast has been upgraded...").
- `app/services/ajax.js`: user-facing messages: "API server is running a newer version of Ghost, please upgrade." → Bookstoast; "Ghost is currently undergoing maintenance..." → "Bookstoast is currently undergoing maintenance...". Leave `isGhostRequest`/`GHOST_REQUEST` identifiers and comments.
- `app/services/ui.js`: `'Ghost Admin - ' + blogTitle` → `'Bookstoast Admin - ' + blogTitle`.
- `app/services/billing.js`: comments only → SKIP.
- `app/services/migrate.js`: `https://migrate.ghost.org` — KEEP (functional), report.
- `app/routes/pro.js`: `titleToken: 'Ghost(Pro)'` → `'Bookstoast Pro'`.
- `app/components/gh-billing-modal.hbs`: "We couldn't load your Ghost(Pro) settings" → "Bookstoast Pro settings".
- `app/components/modals/settings/about.hbs`: help/docs links → mapped; keep legal lines (Rule 3).
- `app/utils/publish-options.js`: `support@ghost.org` → `support@bookstoast.com`.
- `app/services/limit.js`: `https://ghost.org/help/` → `https://bookstoast.com/help/`.
- `app/templates/lexical-editor.hbs`: `https://ghost.org/help/using-the-editor/` → `https://bookstoast.com/help/using-the-editor/`.
- `app/components/gh-post-settings-menu.hbs`: `https://docs.ghost.org/themes/helpers/` → `https://bookstoast.com/docs/themes/helpers/`.
- `app/components/tags/tag-form.hbs`: `https://ghost.org/help/organising-content/#private-tags` → `https://bookstoast.com/help/organising-content/#private-tags`.
- `app/components/editor/publish-options/publish-type.hbs`: `https://docs.ghost.org/newsletters/#bulk-email-configuration` → `https://bookstoast.com/docs/newsletters/#bulk-email-configuration`.
- `app/index.html`: verify already rebranded (should be).
- `public/assets/icons/ghost-logo-orb.svg`: change `<title>Ghost Logo</title>` → `<title>Bookstoast Logo</title>` (keep filename/asset refs).
- DO NOT touch: `multi-list/item.js` ("ghostClick" is a UI term — internal), `README.md`, styles comments, `utils/search.js` comment, test data.
- CHECK these files after editing for other copy you see: `app/templates/setup.hbs`, `app/components/modals/settings/about.hbs`, `app/components/gh-billing-modal.hbs`, and run: `git grep -n "Ghost\|ghost\.org" -- apps/ember-admin/app apps/ember-admin/public/assets/icons apps/ember-admin/app/index.html` → fix any remaining USER-VISIBLE ones; report the rest.
- Update any ember tests that assert the strings you changed (search `apps/ember-admin/tests` for the old strings; update; don't run ember builds).

## Scope C: Other apps (`apps/admin-toolbar/**`, `apps/activitypub/**`, `apps/portal/**`, `apps/comments-ui/**`, `apps/signup-form/**`, `apps/sodo-search/**`, `apps/announcement-bar/**`)
- `apps/admin-toolbar/src/auth.js`: `frame.title = 'Ghost admin authentication'` → 'Bookstoast admin authentication'.
- `apps/admin-toolbar/src/components.js`: aria-label `Open Ghost Admin for ...` → 'Open Bookstoast Admin for ...'. Check file for others.
- `apps/admin-toolbar/src/config.js`: `siteTitle: dataset.siteTitle || 'Ghost'` → `'Bookstoast'`.
- `apps/activitypub/src/components/layout/error/error.tsx`: help links `ghost.org/help/social-web/` → `bookstoast.com/help/social-web/`.
- `apps/activitypub/src/components/layout/sidebar/feedback-box.tsx`: `ghost.org/help/social-web/` → `bookstoast.com/help/social-web/`; `https://activitypub.ghost.org/archive` → `https://bookstoast.com/social-web/archive`; the note URL `https://activitypub.ghost.org/.ghost/activitypub/note/...` → leave? NO → change host to `https://bookstoast.com/social-web/note/...` hmm — actually: use `https://bookstoast.com/social-web` for it. Use best mapping; keep it consistent: activitypub.ghost.org/X → bookstoast.com/social-web/X .
- `apps/activitypub/src/components/layout/sidebar/sidebar.tsx` + `src/views/inbox/components/inbox-list.tsx`: `https://explore.ghost.org/social-web` → `https://bookstoast.com/explore/social-web`.
- `apps/activitypub/src/views/preferences/components/settings.tsx`: help link → mapped.
- `apps/portal/src/actions.js`: `referrerMedium: 'Ghost Recommendations'` → `'Bookstoast Recommendations'` (check nothing depends on the old string; grep repo for 'Ghost Recommendations').
- `apps/portal/src/utils/fixtures-generator.js` + `fixtures.js`: DEV fixtures — leave `static.ghost.org` image URLs, REPORT them.
- `apps/signup-form/index.html` + `preview.html`: dev harness copy "Currently connected to Ghost running at" → "Bookstoast running at". (data-icon URLs: leave, report.)
- `apps/comments-ui`, `apps/sodo-search`, `apps/announcement-bar`: quick grep; fix only clear user-visible Ghost strings; these are mostly clean (identifiers only → skip those).
- `apps/shade/src`: skip storybook stories; fix only non-story user-visible strings if any.
- Re-grep: `git grep -n "Ghost\|ghost\.org" -- apps/admin-toolbar/src apps/activitypub/src apps/portal/src apps/comments-ui/src apps/signup-form apps/sodo-search/src apps/announcement-bar/src` → report remaining intentional items.

## Scope M (me — do not touch): `ghost/core/**`, themes (`ghost/core/content/themes/*`), koenig, packages, tests/snapshots, binary assets.
