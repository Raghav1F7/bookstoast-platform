# Bookstoast Rebrand — EXECUTION PLAN (Pass 2)

Baseline: commit aefdd6c585 (merge of codespaces-rebranding + main). Working tree clean.
Tools: sharp ok (ghost/core node_modules), OCR via /tmp/ocr (tesseract.js), no vision model (broken).
Scripts: ~/.openclaw/workspace/tmp/bookstoast-audit/scripts/ (scan-assets, inspect2 ascii, inspect-colors).

## KEY DECISIONS (final)
1. LINK POLICY: user-visible ghost.org-family links → bookstoast.com equivalents:
   - https://ghost.org/* → https://bookstoast.com/* (same path/query)
   - https://www.ghost.org/* → https://bookstoast.com/*
   - https://docs.ghost.org/* → https://bookstoast.com/docs/*  (keep tail path)
   - https://forum.ghost.org* → https://bookstoast.com/forum
   - https://explore.ghost.org/* (destination links) → https://bookstoast.com/explore/*
   EXCEPTIONS KEPT (functional/legal):
   - stripe.ghost.org (Stripe connect), updates.ghost.org (update checks), explore.ghost.org/api/* endpoints, migrate.ghost.org (migrate tool), static.ghost.org assets (can't rehost — replace/remove branded art only)
   - Legal attribution in About modals (copyright "Ghost Foundation" + MIT + trademark sentence) — KEEP AS IS (attribution, not product brand). License link stays TryGhost? → keep.
   - github.com/TryGhost/* in package metadata → keep; BUT link-to-github-releases.ts output → switch to github.com/Raghav1F7/bookstoast-platform
2. IMAGES:
   - Emails: orb imgs → text wordmark "Bookstoast"; powered.png badge → text link "Powered by Bookstoast".
   - admin images to replace: orb-black-1..5 (400x400→toast art), orb-pink.png (48px→toast pink), orb-squircle.png (160→toast squircle), portal-splash-default-logo.png, explore-default-logo.png, ghost-explore.png (has 'Ghost Explore' text! regenerate illustration), check network/design/integrations pngs & ghost-transistor via OCR.
   - portal gift-card-orb.webp + core gift-card-orb.png → white toast silhouette masks.
   - 404-ghost.png/@2x (ember) → find usage; likely replace with toast silhouette or leave if unused.
   - shade/admin/ember logos + loaders + favicons done by prior pass (verified wordmark OCR "Bookstoast" ok).
3. THEMES (casper + source are submodules; footer says Powered by Ghost):
   - VENDOR both themes (de-submodule, add as regular files), edit footers → "Powered by Bookstoast"/bookstoast.com.
   - Update pre-commit hook guard for empty .gitmodules so commits don't break.
   - Check .gitignore inside themes before adding; force-add needed built assets.
4. Strings: Ghost→Bookstoast for user-visible text; LEAVE: code comments (mostly), identifiers, @tryghost packages, API paths, slack/technical, migrations, internal integration names/slugs, ghostClick (UI term), test data.
   - Change: support@ghost.org→support@bookstoast.com (2 files), titles/tooltips/aria labels, generator metas (ghost_head, private.hbs) → Bookstoast, RSS generator, sitemap.xsl, llms strings, "Team Ghost", email subjects/messages, setup fixtures copy, update-check alert subject?, milestone emails art.
5. Emails: apply wordmark + link swaps; update email-renderer tracking exclusion for bookstoast.com; update snapshots + tests.

## PHASES
P1 emails+core server/frontend strings  [IN PROGRESS]
P2 admin app sweep + admin images
P3 ember sweep (+hook/submodule: themes step)
P4 other apps (portal, activitypub, admin-toolbar, signup dev pages skip)
P5 themes vendoring + footers
P6 tests/snapshots + builds (admin vitest, ghost unit subsets, integrity if needed)
P7 runtime validation attempt (docker compose sqlite) + final grep audit + REBRAND_STATUS + commits (local only)

## TEST/SNAPSHOT NOTES
- private-blogging controller.test.js asserts 'Powered by Ghost' + href ghost.org → UPDATE (private.hbs already rebranded by prior pass; test stale?)
- click-tracking.isolated.test.js references badge URL → update for bookstoast.com
- .snap files (email-previews, batch-sending, automated-emails, member-welcome, cards, settings, site, users, pages, posts, authors, authentication) contain old URLs → scripted swaps
- admin tests to fix: upgrade-banner.test (expects Ghost copy?), explore.acceptance, use-upgrade-route.test, newsletter previews, link-to-github-releases.test
- portal tests: check data-attributes + links after changes
- integrity.test.js hashes: only if default-settings.json changes (mostly done; check publication-cover decision)

## OPEN ITEMS
- decide publication-cover.jpg / feature-image.jpg (inspect content; may be generic → leave)
- milestone images content check (m100)
- ember about.hbs linkToGitHubReleases util location
- network.png / design-settings.png / integrations-settings.png / ghost-transistor.png / stripe-thumb.jpg OCR check → decide
- admin orb-* replacements generation script
- 'Ghost(Pro)' naming → 'Bookstoast Pro' consistently
