const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const ROOTS = [
  '/home/raghav/src/bookstoast-platform/apps',
  '/home/raghav/src/bookstoast-platform/ghost/core/core/frontend',
  '/home/raghav/src/bookstoast-platform/ghost/core/core/server/web',
];
const EXCLUDE = /(node_modules|\/dist\/|\/built\/|\/test\/|\/tests\/|\/mirage\/|fixtures?|\.snap)/i;
const EXT = /\.(png|jpe?g|webp)$/i;
const SVGS = /\.svg$/i;

function walk(dir, out = []) {
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (EXCLUDE.test(p)) continue;
    if (e.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

(async () => {
  const files = ROOTS.flatMap((r) => walk(r));
  const rasters = files.filter((f) => EXT.test(f));
  const svgs = files.filter((f) => SVGS.test(f));
  const rows = [];
  for (const f of rasters) {
    try {
      const img = sharp(f, { failOn: 'none' });
      const meta = await img.metadata();
      const { data, info } = await img
        .resize(96, 96, { fit: 'inside' })
        .ensureAlpha()
        .raw()
        .toBuffer({ resolveWithObject: true });
      let pink = 0,
        orange = 0,
        dark = 0,
        total = info.width * info.height;
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
        if (a < 16) continue;
        if (Math.abs(r - 255) < 60 && Math.abs(g - 26) < 70 && Math.abs(b - 117) < 70) pink++;
        else if (r > 220 && g > 110 && g < 180 && b < 90) orange++;
        else if (r < 45 && g < 45 && b < 45) dark++;
      }
      rows.push({
        f,
        w: meta.width,
        h: meta.height,
        fmt: meta.format,
        pink: (pink / total) * 100,
        orange: (orange / total) * 100,
        dark: (dark / total) * 100,
      });
    } catch (e) {
      rows.push({ f, err: String(e.message).slice(0, 70) });
    }
  }
  rows.sort((a, b) => (b.pink || 0) - (a.pink || 0));
  console.log('=== RASTERS sorted by ghost-pink% (top 60) ===');
  for (const r of rows.slice(0, 60)) {
    if (r.err) console.log(`ERR ${r.f} :: ${r.err}`);
    else
      console.log(
        `${r.pink.toFixed(1).padStart(5)}% pink ${r.orange.toFixed(1).padStart(5)}% orange  ${String(r.w).padStart(5)}x${String(r.h).padEnd(5)} ${r.fmt}  ${r.f}`
      );
  }
  console.log('\n=== ghost/toast/orb-named rasters ===');
  for (const r of rows) {
    if (/ghost|orb|toast|404|logo/i.test(path.basename(r.f))) {
      if (r.err) console.log(`ERR ${r.f} :: ${r.err}`);
      else console.log(`${r.pink.toFixed(1).padStart(5)}% pink ${r.orange.toFixed(1).padStart(5)}% orange  ${String(r.w).padStart(5)}x${String(r.h).padEnd(5)} ${r.fmt}  ${r.f}`);
    }
  }
  console.log('\n=== SVGs mentioning ghost (>=3 hits or ghost in name) ===');
  for (const f of svgs) {
    try {
      const t = fs.readFileSync(f, 'utf8');
      const m = t.match(/ghost/gi);
      if ((m && m.length >= 3) || /ghost|orb|toast/i.test(path.basename(f))) {
        console.log(`${String(m ? m.length : 0).padStart(3)} hits  ${f}`);
      }
    } catch {}
  }
})();
