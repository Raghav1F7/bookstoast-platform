const sharp = require('/home/raghav/src/bookstoast-platform/ghost/core/node_modules/sharp');
const files = process.argv.slice(2);
(async () => {
  for (const f of files) {
    try {
      const meta = await sharp(f, {failOn:'none'}).metadata();
      const { data, info } = await sharp(f, {failOn:'none'}).resize(56, 40, {fit:'contain', background:{r:30,g:30,b:30,alpha:1}}).flatten({background:{r:30,g:30,b:30}}).greyscale().raw().toBuffer({resolveWithObject:true});
      const chars = ' .:-=+*#%@';
      console.log(`\n== ${f.split('/').pop()} (${meta.width}x${meta.height})`);
      for (let y=0; y<info.height; y++) {
        let line='';
        for (let x=0; x<info.width; x++) {
          const v = data[y*info.width+x];
          line += chars[Math.min(9, Math.floor(v/26))];
        }
        console.log(line);
      }
    } catch(e){ console.log('ERR', f, e.message); }
  }
})();
