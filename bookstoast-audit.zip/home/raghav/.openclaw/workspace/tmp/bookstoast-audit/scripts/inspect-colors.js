// Inspect images: dims, alpha, top colors. Usage: node inspect-colors.js file1 file2 ...
const sharp = require('/home/raghav/src/bookstoast-platform/ghost/core/node_modules/sharp');
const fs = require('fs');

(async () => {
  const files = process.argv.slice(2);
  for (const f of files) {
    try {
      const img = sharp(f, { failOn: 'none' });
      const meta = await img.metadata();
      const { data, info } = await img
        .resize(128, 128, { fit: 'inside' })
        .ensureAlpha()
        .raw()
        .toBuffer({ resolveWithObject: true });
      const counts = new Map();
      let transparent = 0;
      const totalPx = info.width * info.height;
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
        if (a < 16) { transparent++; continue; }
        // quantize to 32-levels per channel
        const key = `${r >> 5}.${g >> 5}.${b >> 5}`;
        const entry = counts.get(key) || { n: 0, r: 0, g: 0, b: 0 };
        entry.n++; entry.r += r; entry.g += g; entry.b += b;
        counts.set(key, entry);
      }
      const top = [...counts.values()].sort((x, y) => y.n - x.n).slice(0, 7);
      const fmt = (e) => {
        const r = Math.round(e.r / e.n), g = Math.round(e.g / e.n), b = Math.round(e.b / e.n);
        const hex = '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
        return `${hex}(${((e.n / totalPx) * 100).toFixed(0)}%)`;
      };
      console.log(`\n== ${f}`);
      console.log(`  ${meta.width}x${meta.height} ${meta.format} alpha=${meta.hasAlpha} transparent=${((transparent / totalPx) * 100).toFixed(0)}%`);
      console.log('  ' + top.map(fmt).join(' '));
    } catch (e) {
      console.log(`\n== ${f} ERROR: ${e.message}`);
    }
  }
})();
