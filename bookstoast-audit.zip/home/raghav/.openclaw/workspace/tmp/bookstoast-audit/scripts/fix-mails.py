#!/usr/bin/env python3
"""Bookstoast rebrand — email template fixes (mail service)."""
import re
import pathlib

ROOT = pathlib.Path('/home/raghav/src/bookstoast-platform')
MAIL = ROOT / 'ghost/core/core/server/services/mail/templates'

WORDMARK = (
    '<td align="center" style="padding-top: 20px; padding-bottom: 12px;">'
    '<span style="display: inline-block; font-family: -apple-system, BlinkMacSystemFont, '
    "'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 20px; font-weight: 700; "
    'letter-spacing: -0.02em; color: #15171A;">Bookstoast</span></td>'
)

orb_re = re.compile(
    r'<td align="center" style="padding-top: 20px; padding-bottom: 12px;">'
    r'<img src="https://static\.ghost\.org/v4\.0\.0/images/ghost-orb-\d\.png"[^>]*/></td>'
)

subs = [
    ('<title>Welcome to Ghost</title>', '<title>Welcome to Bookstoast</title>'),
    ('<title>Ghost notification</title>', '<title>Bookstoast notification</title>'),
    ('your email config for your Ghost blog', 'your email config for your Bookstoast site'),
    ('Team Ghost', 'Team Bookstoast'),
    ('href="https://ghost.org"', 'href="https://bookstoast.com"'),
    ('>https://ghost.org</a>', '>https://bookstoast.com</a>'),
    ('<p>Ghost</p>', '<p>Bookstoast</p>'),
]

changed_files = []
for f in sorted(MAIL.rglob('*.html')):
    txt = f.read_text(encoding='utf-8')
    orig = txt
    txt, n1 = orb_re.subn(WORDMARK, txt)
    for old, new in subs:
        txt = txt.replace(old, new)
    if txt != orig:
        f.write_text(txt, encoding='utf-8')
        changed_files.append(str(f.relative_to(ROOT)))

print('CHANGED:')
for c in changed_files:
    print(' ', c)

print()
print('=== remaining Ghost refs in mail templates ===')
for f in sorted(MAIL.rglob('*.html')):
    txt = f.read_text(encoding='utf-8')
    for i, line in enumerate(txt.splitlines(), 1):
        if 'Ghost' in line or 'ghost.org' in line:
            print(f'{f.relative_to(ROOT)}:{i}: {line.strip()[:150]}')
